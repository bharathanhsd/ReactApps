package com.app;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.model.Person;

@Configuration
@EnableAutoConfiguration
@ComponentScan
@Controller
public class DemoApplication {
	
	@ResponseBody
	@RequestMapping("/hello")
	public String defaultHello23467(){
		return "Welcome to page... U created..!!";
	}
	@ResponseBody
	@RequestMapping("/person")
	public List<Person> defaultHello123(){
		List<Person> pesonList = new ArrayList<Person>();
		pesonList.add(new Person("Hello", "World"));
		pesonList.add(new Person("UK", "London"));
		pesonList.add(new Person("America", "US"));
		return pesonList;
	}

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}
}
