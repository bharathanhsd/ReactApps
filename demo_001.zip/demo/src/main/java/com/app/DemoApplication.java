package com.app;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.model.Person;
import com.model.User;

@Configuration
@EnableAutoConfiguration
@ComponentScan
@Controller
public class DemoApplication {
	
	@ResponseBody
	@RequestMapping("/hello")
	public String defaultHello23467(){
		return "Welcome to page... U created..!!";
	}
	@ResponseBody
	@RequestMapping("/person")
	public List<Person> defaultHello123(){
		List<Person> pesonList = new ArrayList<Person>();
		pesonList.add(new Person("Hello", "World"));
		pesonList.add(new Person("UK", "London"));
		pesonList.add(new Person("America", "US"));
		return pesonList;
	}

	@ResponseBody
	@RequestMapping("/userDetails")
	public List<User> getUserDetails(){
		List<User> userDetails = new ArrayList<User>();
		try{
		String content = new String(Files.readAllBytes(Paths.get("c://loginDetails.txt", "")));
		System.out.println(content);
		String lines[] = content.split("\\r?\\n");
		System.out.println("List of values.. : "+lines[0]);
		for(int i=0;i<lines.length;i++){
			
			String fields[] = lines[i].split(",");
			System.out.println("Fields Value.. :"+fields[0]);
			User user = new User();
			user.setUserName(fields[0]);
			user.setPassword(fields[1]);
			user.setIsActive(fields[2]);
			userDetails.add(user);
		}
		//ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
		//String json = ow.writeValueAsString(userDetails);
		//System.out.println(userDetails.toString());
		//System.out.println(json);
		}catch(Exception e){
			e.printStackTrace();
		}
		return userDetails;
	}
	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}
}
