/**
 * 
 */
package com.controller;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.model.Person;

/**
 * @author Bharath
 *
 */

@Configuration
@EnableAutoConfiguration
@ComponentScan
@Controller
public class RestAppController {

	@ResponseBody
	@RequestMapping("/person123")
	public Person defaultHello(){
		return new Person("Hello", "World");
	}

}
